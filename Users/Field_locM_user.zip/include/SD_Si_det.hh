#ifndef SD_Si_det_HH
#define SD_Si_det_HH

#include <G4Material.hh>
#include "G4NistManager.hh"

#include "G4VSensitiveDetector.hh"
#include "G4Step.hh"
#include "G4HCofThisEvent.hh"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>

#include "SD_Si_det_hit.hh"

class SD_Si_det : public G4VSensitiveDetector
{
 public:
  SD_Si_det(G4String SDname);
  ~SD_Si_det();

  void Initialize(G4HCofThisEvent* HCE);
  G4bool ProcessHits(G4Step* astep, G4TouchableHistory*); 
  void EndOfEvent(G4HCofThisEvent* HCE);

  G4double GetSumE(G4int i) const {return SumE[i-1];}
  void AddSumE(double e, G4int i) {SumE[i-1]+=e;}

 private:
  std::ofstream hit_SD_Si_det[10];
  G4double SumE[10];
  
  SD_Si_det_hitCollection *hitCollection;
  G4int collectionID;    
};

#endif

