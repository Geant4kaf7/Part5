//#pragma once

#include <G4UserRunAction.hh>
#include <G4Run.hh>
#include "globals.hh"
#include <ctime>
#include <iomanip>
#include <fstream>

class RunAct : public G4UserRunAction {
public:
 RunAct(std::ofstream& ofsa);
  ~RunAct();
 std::ofstream *f_act;

 void BeginOfRunAction(const G4Run*);
 void EndOfRunAction(const G4Run*);
};
