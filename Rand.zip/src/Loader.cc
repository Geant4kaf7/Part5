#include <Loader.hh>
#include <Geometry.hh>
#include <Action.hh>
#include <G4Types.hh>
#include <globals.hh>

Loader::Loader(int argc, char **argv, std::ofstream& ofsa) 
{
 this->ofs_sn=&ofsa;
 (*ofs_sn) << std::setw(12) << "Hi from Loader!" << std::endl;

 runManager = new G4RunManager;

 CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
 CLHEP::HepRandom::setTheSeed(time(NULL)+getpid());
 G4Random::showEngineStatus();
 (*ofs_sn) << "seed=" << CLHEP::HepRandom::getTheSeed() <<G4endl;
 (*ofs_sn) << "seeds=" << *CLHEP::HepRandom::getTheSeeds() <<G4endl;
// CLHEP::HepRandom::saveEngineStatus();
// CLHEP::HepRandom::restoreEngineStatus();
 
 std::ostringstream os2;
 os2<<"Loader_"<<G4Threading::G4GetThreadId()<<".rndm";
// G4Random::saveEngineStatus(os2.str().c_str());
// G4Random::restoreEngineStatus(os2.str().c_str());
 
 runManager->SetUserInitialization(new Geometry(*this->ofs_sn));

 G4VModularPhysicsList* physicsList = new QBBC;
 physicsList->RegisterPhysics(new G4StepLimiterPhysics());
 runManager->SetUserInitialization(physicsList);
 runManager->SetUserInitialization(new Action(*this->ofs_sn));
 runManager->Initialize();
 G4VisManager* visManager = new G4VisExecutive;
 visManager->Initialize();
 G4UImanager *UImanager = G4UImanager::GetUIpointer();

 if (argc != 1) 
 {
// batch mode
  G4String command = "/control/execute ";
  G4String fileName = argv[1];
  UImanager->ApplyCommand(command + fileName);
 }
 else
 {
  G4UIExecutive *ui = new G4UIExecutive(argc, argv, "qt"); //Here we can redefine win32/qt interface
  UImanager->ApplyCommand("/control/execute vis.mac");
  ui->SessionStart();
  delete ui;
  }
 }

 Loader::~Loader()
 {
  delete runManager;
  delete visManager;
  (*ofs_sn) << std::setw(12) << "Bye from Loader!" << std::endl; 
 }
